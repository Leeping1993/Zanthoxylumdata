# Hybrid capture resolves the phylogeny of *Tetradium* (Rutaceae) and supports the inclusion of a species from Sulawesi

[https://doi.org/10.5061/dryad.h18931zsp](https://doi.org/10.5061/dryad.h18931zsp)

##### The dataset consists of genetic data obtained through a comprehensive experimental pipeline utilizing the HybPhyloMaker pipeline (Fér and Schmickl, 2018). This pipeline automates various steps, including quality trimming of reads, reconstruction of phylogenetic trees, and quartet sampling. The process involved several software tools: Trimmomatic v0.33 (Bolger et al., 2014) for adapter and quality trimming, FastUniq v1.1 (Xu et al., 2012) for removing duplicated reads, Bowtie2 v2.2.9 (Langmead and Salzberg, 2012) for read mapping, Kindel v0.1.4 (Constantinides and Robertson, 2017) for creating consensus sequences, MAFFT v7.304 (Katoh and Standley, 2013) for sequence alignment, and RAxML v8.2.12 (Stamatakis, 2014) for maximum likelihood analysis.

##### After data processing, alignments with significant missing data or taxa were filtered out, leaving 258 out of the targeted 347 genes for further analysis. Phylogenetic inference was conducted using two approaches: concatenation of all alignments as a single locus and coalescent-based species tree analysis using individual gene trees. RAxML was utilized for maximum likelihood analysis with bootstrap replicates, and ASTRAL-III v5.6.1 (Mirarab et al., 2014; Zhang et al., 2018) for species tree reconstruction.

##### The resulting phylogenetic trees were evaluated for conflicts between gene trees and species tree branches using quartet support analysis. Visualization of the trees was done using FigTree v1.4.4 ([http://tree.bio.ed.ac.uk/software/figtree/.](http://tree.bio.ed.ac.uk/software/figtree/.)





##

